import React from "react";

const Footer = () => {
    return (
        <footer className="Footer">
      <span className="body-small-14">
        © Daniel Oľšavský 2025 Štýlové profily – prototyp
      </span>
        </footer>
    );
};

export default Footer;
